package com.example.empsal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, RadioGroup.OnCheckedChangeListener {
    RadioButton phd,master, bachelor, frsh, exprt;
    CheckBox beng, bfr, bh, bsp, bpor;
    TextView yrstv,salary;
    EditText yearsT;
    Button calc;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        phd=findViewById(R.id.rbphd);
        master=findViewById(R.id.rbmas);
        bachelor=findViewById(R.id.rbbac);
        yrstv=findViewById(R.id.tvyrs);
        salary=findViewById(R.id.saltx) ;
        yearsT=findViewById(R.id.txtyrs);
        calc=findViewById(R.id.buttonok);
        frsh=findViewById(R.id.rbfre);
        exprt=findViewById(R.id.rbexp);
        rg=findViewById(R.id.radioGroup2);

        calc.setOnClickListener(this);
        rg.setOnCheckedChangeListener(this);

        beng=findViewById(R.id.cbeng);
        bpor=findViewById(R.id.cbpor);
        bfr=findViewById(R.id.cbfre);
        bsp=findViewById(R.id.cbsp);
        bh=findViewById(R.id.cbhin);
    }
    public int getSalary(){
        int sal =0;
        if(phd.isChecked())
            sal=6500;
        else if(master.isChecked())
            sal=5800;
        else
            sal=5800;
        return sal;

    }
    public int getLanguage()
    {
        int lang=0;
        if(beng.isChecked()){
            if(bfr.isChecked())
                lang+=100;
            if(bh.isChecked())
                lang+=100;
            if(bsp.isChecked())
                lang+=100;
            if(bpor.isChecked())
                lang+=100;
        }
        else
            lang=0;
        return lang;
    }

    @Override
    public void onClick(View view) {
        double sal=0;
        int noYrs=0;
        if(exprt.isChecked()){
            if(!yearsT.getText().toString().equals(""))
                noYrs=Integer.parseInt(yearsT.getText().toString());
            else
                Toast.makeText(getApplicationContext(),"Please enter no of experience years",Toast.LENGTH_LONG).show();
        }
        sal=getSalary()+getLanguage()+noYrs*100;
        sal*=12;
        String sa=String.format("%.2f",sal);
        salary.setText(sa);
    }

    @Override
    public void onCheckedChanged(RadioGroup rg, int i) {
        if(rg.getCheckedRadioButtonId()==R.id.rbfre){
            yearsT.setVisibility(View.INVISIBLE);
            yrstv.setVisibility(View.INVISIBLE);
        }
        else if(rg.getCheckedRadioButtonId()==R.id.rbexp){
            yearsT.setVisibility(View.VISIBLE);
            yrstv.setVisibility(View.VISIBLE);

        }
    }
}
